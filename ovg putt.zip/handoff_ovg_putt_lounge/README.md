# Handoff: OVG Golf & Putt Lounge

## Overview
Three separate marketing-site redesigns, one HTML file each. All three are modernizations of live sites: each keeps the real business's content, contact details, service list and brand colors, restructured into a 2026 single-page layout with scroll reveals, hover states and working section navigation.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing intended look and behavior, **not production code to copy directly**.

The task is to **recreate these designs in the target codebase's existing environment** (Next.js, Astro, WordPress theme, Webflow, etc.) using its established patterns, component structure and CSS approach. If no environment exists yet, pick the framework that fits the project — these are content-driven marketing sites, so a static-site generator (Astro/Next static export) or a CMS theme is the natural fit, with the copy moved into a CMS/content layer rather than hardcoded.

Implementation notes that matter when porting:
- Every style in these files is an **inline style** for prototype-streaming reasons. Do not carry that over — convert to the codebase's CSS solution (CSS modules, Tailwind, SCSS). The token tables below give you the values.
- All interaction is driven by a small imperative script attached to `data-*` attributes (`data-reveal`, `data-card`, `data-svc`, `data-row`, `data-scope`, `data-q`, `data-chip`). In a component framework, re-express these as component state + CSS transitions, not DOM querying.
- The hero headline reveal is a **CSS keyframe** (`line-rise`) whose resting state is visible — keep that property (never gate content visibility on JS).
- `support.js` is the prototype runtime that renders these files in a browser. It is **not** part of the design and should not be ported.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, copy and interaction behavior. Recreate pixel-accurately using the codebase's libraries. Type scales use `clamp()` and layouts use `repeat(auto-fit, minmax(...))` — the designs are fully fluid from ~360px to ~1600px with no fixed breakpoints except the nav collapse.

---

# 2. OVG Golf & Putt Lounge

Nightlife-meets-golf. Near-black room, neon amber, turf green, cream.

## Design tokens
| Token | Value | Use |
|---|---|---|
| Night | `#0C0E0A` | Page ground |
| Cream | `#EFE8D8` | Text on dark; Rates section background |
| Neon | `#F7C948` (var `--neon`) | Accent, prices, CTA |
| Turf | `#6FA83C` (var `--turf`) | Marquee band, Visit section, list numerals |
| Display font | Anton (single weight), uppercase, `letter-spacing -.01em` | |
| Body font | Archivo 400–700 | |
| Mono font | Space Mono 400/700 — `letter-spacing .14–.24em` | Nav, labels, buttons |
| Container | `max-width: 1520px`; gutter `clamp(16px,4vw,40px)` | |
| Radius | **Square everywhere** (2px max) — deliberate contrast to Bulldog | |

## Sections
1. **Header** — fixed, `rgba(12,14,10,.82)` + 14px backdrop blur, 76px → 62px on scroll. Wordmark "OVG" + stacked neon "PUTT LOUNGE". Mono nav: Sim Bay, Mini Putt, Rates, Private Events, FAQ, Visit. Neon "Book now" button → `https://ovgputtlounge.resova.us/`. Below 1120px nav hides, "MENU" button opens a full-screen panel.
2. **Hero** — their banner photo with a **parallax** transform driven by scroll (`scale(1.06 + y*0.00012) translateY(y*0.06)`), radial + linear scrims. Flickering neon "NOW OPEN · KELOWNA" badge (`ovg-flicker` 6s). Headline `clamp(48px,11vw,168px)/1.02` uppercase: "Practice. / **Party.** / Play." — middle line neon with a 42px glow. Two booking buttons (Birrdi for sim bays, Resova for mini putt). Stat strip: 9 holes / 1 bay / 50 patio seats / $10 drop-in, all count-up.
3. **Marquee** — turf band, Anton uppercase, 38s loop.
4. **Two ways to play** — two tall cards (min-height `clamp(420px,46vw,580px)`), photo + bottom scrim, neon kicker, big price, description, underlined CTA. Hover: image `1.05 → 1.13`, border turns neon, CTA gap opens 10 → 18px.
5. **The vibe** — copy column + three-image mosaic (wide bar shot spanning both columns, cocktails, sunset patio).
6. **Rates** — cream section, four-column rows: service / description / price / button. Simulator $40/hr (up to 8 players), Putt Lounge drop-in $10 per 9 holes or $18 double lap, Private Events custom.
7. **Private events** — group photo background at 96→55% black gradient, copy + three bordered tags, and a glass enquiry card (name/date/heads/email) whose button label swaps to "Sent — talk soon".
8. **FAQ** — five-item accordion, one open at a time, `+` rotates 135°, `max-height` from `scrollHeight`.
9. **Visit** — turf green. Address `106-730 Vaughan Ave`, phone `250-801-7554`, email `ovgkelowna@gmail.com`, hours line ("posted weekly on Instagram" — they don't publish fixed hours), three stacked action buttons.
10. **Footer** — wordmark, Play / Info / Say hi columns, legal row.

## Booking + social links (real, keep them)
- Sim bay: `https://app.birrdi.com/u/reserve?team_booking_link_id=okanagan-virtual-golf-kelowna`
- Mini putt: `https://ovgputtlounge.resova.us/`
- Instagram `@ovgkelowna`, Facebook `profile.php?id=61576310855896`

---

## Shared interaction spec
- **Scroll reveals** — elements below 92% of the viewport start at `opacity 0 / translateY(24px)` and animate to rest on intersection (`rootMargin 0 0 -12% 0`, threshold .08), each element once. Respect `prefers-reduced-motion: reduce` (all three sites already do).
- **Counters** — integers ease out over ~1s on first intersection at 60% visibility. Bulldog's "1965" counts from 1905 so it reads as a year, not a tally.
- **Headline masks** — a fixed-height `overflow: hidden` wrapper per line, inner span animated `translateY(108%) → 0`. The wrapper carries `padding-bottom: .14em; margin-bottom: -.14em` so descenders (g, y, p) are not clipped.
- **Nav collapse** — pure CSS media query, so navigation works before/without JS. Keep that guarantee.
- **Forms** — all three are non-submitting prototypes with optimistic label swaps. Wire to the real endpoint (Bulldog's is a WordPress quote form; OVG uses Resova/Birrdi for bookings but needs an events enquiry endpoint; Red Mechanical has no form today).

## Assets (`assets/`)
All photography is **AI-generated placeholder imagery supplied by the client for layout purposes** — replace with real photography before launch. File names describe contents.

- `logo-bulldog.png` — **extracted from a screenshot of the live site**; get the original vector/PNG from the client. OVG has no logo file, so its wordmark is currently typeset in Anton.
- Bulldog: `bdb-press-floor`, `bdb-plastic-bags`, `bdb-paper-bags`, `bdb-rollstock`, `bdb-family`, `bdb-grocery-shelf`, `bdb-compliance`.
- OVG: `ovg-cocktails`, `ovg-patio`, `ovg-group`. The hero, both booking cards and the wide bar shot **hotlink the client's own Wix CDN** (`static.wixstatic.com/media/4ad306_…`) — download and self-host these on build.
- Red Mechanical: `rm-mechroom-hero`, `rm-mechroom-custom`, `rm-townhouse-framing`, `rm-commercial-water-entry`, `rm-boilerroom-360`, `rm-manifold-detail`, `rm-dwv-roughin`, `rm-backflow-assembly`, `rm-parkade-services`, `rm-finished-ensuite`.
- Bulldog's hero video hotlinks `bulldogbag.com/wp-content/uploads/2024/09/bulldog_banner.mp4` — self-host it (and compress: add a WebM source and a poster).

## Files in this bundle
```
Bulldog Bag.dc.html      design reference — Bulldog Bag
OVG Putt Lounge.dc.html  design reference — OVG Putt Lounge
Red Mechanical.dc.html   design reference — Red Mechanical
support.js               prototype runtime (needed only to open the HTML files; do not port)
assets/                  images referenced by the three files
```

## Before launch (open items)
1. Sample Red Mechanical's exact brand red from their logo.
2. Source real logo files for Bulldog Bag and OVG.
3. Replace all placeholder photography; self-host the OVG Wix images and the Bulldog video.
4. Confirm OVG's opening hours (currently "posted weekly on Instagram") and whether Red Mechanical's virtual tours are still live.
5. Add real form endpoints, plus SEO/meta, favicons, analytics and accessibility passes (visible focus states are not specified in these prototypes).
